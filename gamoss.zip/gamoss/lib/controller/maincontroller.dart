import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:gamoss/views/account_page.dart';
import 'package:gamoss/views/add_funds.dart';
import 'package:gamoss/views/attendance.dart';
import 'package:gamoss/views/dpr.dart';
import 'package:gamoss/views/expense_approvel.dart';
import 'package:gamoss/views/expense_manager.dart';
import 'package:gamoss/views/project.dart';
import 'package:gamoss/views/wallet_page.dart';
import 'package:get/get.dart';
import 'package:open_file/open_file.dart';

class MainController extends GetxController{
  final myControllerWallet = TextEditingController();
  final myControllerRemarks = TextEditingController();
  final myControllerExpense = TextEditingController();
  final myControllerExpenseRemark = TextEditingController();
  RxString? selectCustomer = "SelectCustomer".obs;
  RxString? assignTo = "Assign to".obs;
  RxBool? isImageSelected = false.obs;
  RxList<TextEditingController> c1=<TextEditingController>[].obs;
  RxList<TextEditingController> q1=<TextEditingController>[].obs;

  var customer;
  var projectAssign;
  Rx<int>pageIndex= 0.obs;
  final pages = [
    const WalletPage(),
    const DPRPage(),
    const ExpenseManagerPage(),
    const Project(),
    const AddFundsPage(),
    const ExpenseApprovalPage(),
    const AccountPage(),
    const AttendancePage(),
  ];
  FilePickerResult? result;
  PlatformFile? file;
 Future<void> pickFiless() async {
     result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ["jbg","png","mp3","pdf"]
    );
    if(result==null)return ;
     file =result!.files.first;
    // openFile(file!);
  }
  void openFile(PlatformFile file) {
   print("File Name");
    OpenFile.open(file.path);
    print("File Name${file.name}");
    print("bytes${file.bytes}");
    print("PAth${file.path}");
    print("size${file.size}");
  }
}