import 'package:flutter/material.dart';

Color deepOrange = const Color(0xFFF7043);
Color whiteshade = const Color(0xFFF8F9FA);
Color primaryColor = const Color(0xFFF57C00);
Color lightblueshade = const Color(0xFF758CC8);
Color grayshade = const Color(0xFF9FA4AF);
Color lightblue = const Color(0xFF4B68D1);
Color blackshade = const Color(0xFF555555);

