import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gamoss/constant/constant.dart';

class MyHeaderDrawer extends StatelessWidget {
  const MyHeaderDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: primaryColor,
        height: 100,
        child: Padding(
          padding: const EdgeInsets.all(13.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children:  [
              const CircleAvatar(
                backgroundImage: NetworkImage("https://eitrawmaterials.eu/wp-content/uploads/2016/09/person-icon.png"),
                radius: 40,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text("Ajay Kumar Pal",style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold),),
                    Text("ajay@gmail.com",style: TextStyle(color: Colors.black,fontSize: 15.0),),
                  ],
                ),
              ),

            ],
          ),
        ),
      )
    );
  }
}