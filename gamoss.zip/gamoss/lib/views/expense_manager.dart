
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:gamoss/constant/constant.dart';
import 'package:gamoss/controller/maincontroller.dart';
import 'package:get/get.dart';

class ExpenseManagerPage extends StatelessWidget {
  const ExpenseManagerPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    FilePickerResult? result;
    PlatformFile? fileExpense;
    Future<void> pickFilessExpense() async {
      result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ["jbg","png","mp3","pdf"],
      );
      if(result==null)return ;
      fileExpense =result!.files.first;

      // openFile(file!);
    }
    MainController mainController=Get.find();
    return SingleChildScrollView(
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 14.0,top: 20,),
                child: Container(
                  height: 40,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: const LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [
                          Colors.transparent,
                          Colors.transparent,
                        ],
                      )
                  ),
                  alignment: Alignment.topLeft,
                  child:  Text("Expense Manager",style: TextStyle(
                    color: primaryColor,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,

                  ),),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 14.0,top: 20,right: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 40,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          gradient: const LinearGradient(
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                            colors: [
                              Colors.transparent,
                              Colors.transparent,
                            ],
                          )
                      ),
                      alignment: Alignment.topLeft,
                      child:  const Text(" My Expense ",style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.normal,

                      ),),
                    ),
                    Container(
                      height: 40,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          gradient: const LinearGradient(
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                            colors: [
                              Colors.transparent,
                              Colors.transparent,
                            ],
                          )
                      ),
                      alignment: Alignment.topLeft,
                      child:  const Text("Status",style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.normal,

                      ),),
                    ),
                  ],
                ),
              ),
              Container(
                decoration:  BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top:Radius.circular(20),bottom:Radius.circular(20) ),
                  color: Colors.grey.shade200,
                  boxShadow: [
                    BoxShadow(
                      color: primaryColor,
                      offset: const Offset(0.0, 1.0), //(x,y)
                      blurRadius: 2.0,
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.only(left: 0.0),
                  child: ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount:14,
                      itemBuilder: (BuildContext context ,int index){
                        return  ListTile(
                          subtitle: const Text("transaction"),
                          leading: Image.asset('assets/expense.png',
                            height: 60,
                            width: 60,
                          ),

                          trailing:  Text("Approve", style: TextStyle(
                              color: primaryColor,fontSize: 15),),
                          title:  Text("Expenses",style: TextStyle(
                            color: Colors.brown.shade700,
                            fontWeight: FontWeight.bold,
                          ),),
                        );
                      }),
                ),
              ),
            ],
          ),
          InkWell(
            onTap: (){
              showDialog(context: context, builder: (context){

                return  StatefulBuilder(
                  builder: (BuildContext context, void Function(void Function()) setState) {
                    return AlertDialog(
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(0),
                          )
                      ),
                      backgroundColor: Colors.white,
                      title: const Text("Add Expense",style: TextStyle(
                        color: Colors.brown,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),),
                      content: SizedBox(
                        height: 200,
                        width: MediaQuery.of(context).size.width,
                        child: Column(
                          children: [
                            Container(
                              child: TextField(
                                cursorColor: Colors.brown,
                                keyboardType: TextInputType.number,
                                style:  const TextStyle(
                                  color: Colors.black,
                                ),
                                onChanged: (value){
                                },
                                controller: mainController.myControllerExpense,
                                decoration:   InputDecoration(
                                  hintText: "Enter Amount",
                                  labelStyle: const TextStyle(
                                    color: Colors.brown,
                                  ),
                                  enabledBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.brown,width: 2.0),
                                  ),
                                  focusedBorder: const UnderlineInputBorder(
                                    borderSide: BorderSide(color:  Colors.black),
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 20),
                            TextField(
                              cursorColor: Colors.brown,
                              keyboardType: TextInputType.name,
                              style:  const TextStyle(
                                color: Colors.black,

                              ),
                              onChanged: (value){

                              },
                              controller: mainController.myControllerExpenseRemark,
                              decoration:  const InputDecoration(
                                hintText: "Remark",
                                labelStyle: TextStyle(
                                  color: Colors.black,
                                ),
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.brown,width: 2),
                                ),
                                focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color:  Colors.black,width: 1),
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: (){
                                pickFilessExpense();
                              },
                              child: Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child:
                                    (mainController.file=="pdf")?
                                    Image.asset("assets/pdfimage.png",height: 49,width:50,):
                                    Image.asset("assets/folder icon_3762805.png",height: 40,width:50,),
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      (fileExpense==null)?Container():Container(
                                        width: 100,
                                        child: Text(fileExpense!.name.toString(),style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                        ),),
                                      )
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      actions: [
                        Center(
                          child: MaterialButton(
                            onPressed: () {  },
                            child: const Text("Request"),
                            color: primaryColor,
                          ),
                        )
                      ],
                    );
                  },
                );
              });
            },
            child: Padding(
              padding: const EdgeInsets.only(right: 0,bottom: 20),
              child: Image.asset("assets/add.png",height: 100,color: primaryColor,)







            ),
          ),

        ],
      ),
    );
    
  }
}
