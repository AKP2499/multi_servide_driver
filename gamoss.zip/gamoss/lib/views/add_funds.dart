import 'package:flutter/material.dart';
import 'package:gamoss/constant/constant.dart';
import 'package:gamoss/controller/maincontroller.dart';
import 'package:get/get.dart';

class AddFundsPage extends StatefulWidget {
  const AddFundsPage({Key? key}) : super(key: key);

  @override
  _AddFundsPageState createState() => _AddFundsPageState();
}

class _AddFundsPageState extends State<AddFundsPage> {

  MainController mainController =Get.put(MainController());
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 20.0,top: 20),
      child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children:  [
             Text("ADD Funds",style: TextStyle(
              color: primaryColor,
              fontWeight: FontWeight.bold,
              fontSize: 28.0,
            ),
             ),
            Padding(
              padding: const EdgeInsets.only(right: 18.0,top: 20),
              child: Container(
                padding: const EdgeInsets.only(top: 4,left: 10),
                height: 60,
                decoration: BoxDecoration(
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 1.0,
                        spreadRadius: 0.0,
                        offset: Offset(1.0, 1.0), // shadow direction: bottom right
                      )
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5.0),
                    border: Border.all(color: Colors.grey)),
                child: Obx(()=>
                   Padding(
                     padding: const EdgeInsets.only(right: 20.0),
                     child: DropdownButton<String>(
                       borderRadius: BorderRadius.circular(15.0),
                      onTap: (){
                        FocusScope.of(context).unfocus();
                      },
                      value: mainController.selectCustomer!.value,
                      underline:const Padding(
                        padding: EdgeInsets.all(5),
                      ),
                      isExpanded: true,
                      hint: const Text(
                        "Select Customer",
                        style: TextStyle(color: Colors.grey),
                      ),
                      alignment: Alignment.center,
                      style: const TextStyle(color: Colors.black),
                      items: <String>[
                        "SelectCustomer",
                        "Ajay",
                        "Tarun",
                        "Shadaab",
                        "Anubhav",
                        "Anoop"
                      ].map((String value){
                        return DropdownMenuItem<String>(
                          alignment: Alignment.centerLeft,
                          child:
                        Container(
                          width: 120,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                              value,
                              style: const TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                          ),
                        ),
                          value: value,
                        );
                      }).toList(),
                      onChanged: (value){
                        mainController.customer=value!;
                        mainController.selectCustomer!.value=value;
                      },
                  ),
                   ),
                ),
              ),
            ),
            Container(
              decoration:  BoxDecoration(
                  borderRadius: BorderRadius.circular(5.0),
                  boxShadow:const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 1.0,
                      spreadRadius: 0.0,
                      offset: Offset(1.0, 1.0), // shadow direction: bottom right
                    )
                  ]
              ),

              margin: const EdgeInsets.only(left: 0,right: 20,top: 20),
              child: TextField(
                keyboardType: TextInputType.name,
                buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) {},
                onChanged: (value){},
                decoration:  InputDecoration(
                  enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white,width: 2.0)
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: 'Amount',
                  hintStyle: const TextStyle(color: Colors.grey),
                  focusedBorder:  OutlineInputBorder(
                      borderSide: BorderSide(color: primaryColor)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
            Container(
              decoration:  BoxDecoration(
                  borderRadius: BorderRadius.circular(5.0),
                  boxShadow:const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 1.0,
                      spreadRadius: 0.0,
                      offset: Offset(1.0, 1.0), // shadow direction: bottom right
                    )
                  ]
              ),

              margin: const EdgeInsets.only(left: 0,right: 20,top: 20),
              child: TextField(
                keyboardType: TextInputType.name,
                buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) {},
                onChanged: (value){},
                decoration:  InputDecoration(
                  enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white,width: 2.0)
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: 'Remarks',
                  hintStyle: const TextStyle(color: Colors.grey),
                  focusedBorder:  OutlineInputBorder(
                      borderSide: BorderSide(color: primaryColor)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),

                  ),
                ),
              ),
            ),
            InkWell(
              onTap: () async {


                await mainController.pickFiless();
                setState(() {

                });
                },
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Image.asset("assets/folder icon_3762805.png",height: 100,width: 100,),
                  ),
                 Column(
                   crossAxisAlignment: CrossAxisAlignment.start,
                   children: [
                     const SizedBox(height: 10,),
                     // (mainController.file==null)?Container():Image.file(File(mainController.file!.path.toString()),width: 80,height: 80,),
                     const SizedBox(height: 10,),
                     (mainController.file==null)?Container():Container(
                       width: 180,
                       child: Text(mainController.file!.name.toString(),style: const TextStyle(
                         color: Colors.black,
                       ),),
                     )
                   ],
                 )

                ],
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(0, 40, 20, 10),
              padding: const EdgeInsets.fromLTRB(10,2,10,2),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: primaryColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextButton(onPressed: () {

              },
                child: const Text("Request", style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


