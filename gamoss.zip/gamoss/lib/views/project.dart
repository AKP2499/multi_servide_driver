import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gamoss/constant/constant.dart';
import 'package:gamoss/controller/maincontroller.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class Project extends StatefulWidget {
  const Project({Key? key}) : super(key: key);

  @override
  _ProjectState createState() => _ProjectState();
}

class _ProjectState extends State<Project> {
  TextEditingController startDate = TextEditingController();
  TextEditingController endDate = TextEditingController();
  MainController mainController =Get.put(MainController());
  final String _startDate = "Not set";
  final String _endDate ="Not set";
  @override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children:  [
            Padding(
              padding: const EdgeInsets.only(left: 20.0,top: 20),
              child: Text("Project",style: TextStyle(
                color: primaryColor,fontSize: 35,
                fontWeight: FontWeight.bold,
              ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: Container(
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        decoration:  BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            boxShadow:const [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 1.0,
                                spreadRadius: 0.0,
                                offset: Offset(1.0, 1.0), // shadow direction: bottom right
                              )
                            ]
                        ),

                        margin: const EdgeInsets.only(left: 0,right: 20,top: 20),
                        child: TextField(
                          keyboardType: TextInputType.name,
                          buildCounter: (context,
                              {required currentLength, required isFocused, maxLength}) {},
                          onChanged: (value){

                          },
                          decoration:  InputDecoration(
                            enabledBorder: const OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.white,width: 2.0)
                            ),
                            fillColor: Colors.white,
                            filled: true,
                            hintText: 'Name',
                            hintStyle: const TextStyle(color: Colors.grey),
                            focusedBorder:  OutlineInputBorder(
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        decoration:  BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            boxShadow:const [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 1.0,
                                spreadRadius: 0.0,
                                offset: Offset(1.0, 1.0), // shadow direction: bottom right
                              )
                            ]
                        ),

                        margin: const EdgeInsets.only(left: 0,right: 20,top: 20),
                        child: TextField(
                          keyboardType: TextInputType.name,
                          buildCounter: (context,
                              {required currentLength, required isFocused, maxLength}) {},
                          onChanged: (value){

                          },
                          decoration:  InputDecoration(
                            enabledBorder: const OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.white,width: 2.0)
                            ),
                            fillColor: Colors.white,
                            filled: true,
                            hintText: 'description',
                            hintStyle: const TextStyle(color: Colors.grey),
                            focusedBorder:  OutlineInputBorder(
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        decoration:  BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            boxShadow:const [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 1.0,
                                spreadRadius: 0.0,
                                offset: Offset(1.0, 1.0), // shadow direction: bottom right
                              )
                            ]
                        ),

                        margin: const EdgeInsets.only(left: 0,right: 20,top: 20),
                        child: TextField(
                          controller: startDate,
                          keyboardType: TextInputType.name,
                          buildCounter: (context,
                              {required currentLength, required isFocused, maxLength}) {},
                         onTap: ()async{
                           FocusScope.of(context).unfocus();
                           DateTime? pickedDate = await showDatePicker(
                               context: context, initialDate: DateTime.now(),
                               firstDate: DateTime(2000), //DateTime.now() - not to allow to choose before today.
                               lastDate: DateTime(2101)
                           );
                           if(pickedDate!=null){
                             print(pickedDate);
                             String formattedDate =DateFormat('yyyy-MM-dd').format(pickedDate);
                             print(formattedDate);
                             setState(() {
                               startDate.text=formattedDate;
                             });
                           }else{
                             print("Date is not selected");
                           }
                         },
                          decoration:  InputDecoration(
                            enabledBorder: const OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.white,width: 2.0)
                            ),
                            fillColor: Colors.white,
                            filled: true,
                            hintText: 'Start Date',
                            hintStyle: const TextStyle(color: Colors.grey),
                            focusedBorder:  OutlineInputBorder(
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Container(
                        decoration:  BoxDecoration(
                            borderRadius: BorderRadius.circular(5.0),
                            boxShadow:const [
                              BoxShadow(
                                color: Colors.black26,
                                blurRadius: 1.0,
                                spreadRadius: 0.0,
                                offset: Offset(1.0, 1.0), // shadow direction: bottom right
                              )
                            ]
                        ),
                        margin: const EdgeInsets.only(left: 0,right: 20,top: 20),
                        child: TextField(
                          controller: endDate,
                          keyboardType: TextInputType.name,
                          buildCounter: (context,
                              {required currentLength, required isFocused, maxLength}) {},
                         onTap: ()async{
                           FocusScope.of(context).unfocus();
                           DateTime? pickedDate = await showDatePicker(
                               context: context, initialDate: DateTime.now(),
                               firstDate: DateTime(2000), //DateTime.now() - not to allow to choose before today.
                               lastDate: DateTime(2101)
                           );
                           if(pickedDate!=null){
                             print(pickedDate);
                             String formattedDate =DateFormat('yyyy-MM-dd').format(pickedDate);
                             print(formattedDate);
                             setState(() {
                               endDate.text=formattedDate;
                             });
                           }else{
                             print("Date is not selected");
                           }
                         },
                          decoration:  InputDecoration(
                            enabledBorder: const OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.white,width: 2.0)
                            ),
                            fillColor: Colors.white,
                            filled: true,
                            hintText: 'End Date',
                            hintStyle: const TextStyle(color: Colors.grey),
                            focusedBorder:  OutlineInputBorder(
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 18.0,top: 20),
                        child: Container(
                          padding: const EdgeInsets.only(top: 4,left: 10),
                          height: 60,
                          decoration: BoxDecoration(
                              boxShadow: const [
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 1.0,
                                  spreadRadius: 0.0,
                                  offset: Offset(1.0, 1.0), // shadow direction: bottom right
                                )
                              ],
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5.0),
                              border: Border.all(color: Colors.grey)),
                          child: Obx(()=>
                              Padding(
                                padding: const EdgeInsets.only(right: 20.0),
                                child: DropdownButton<String>(
                                  borderRadius: BorderRadius.circular(15.0),
                                  onTap: (){
                                    FocusScope.of(context).unfocus();
                                  },
                                  value: mainController.assignTo!.value,
                                  underline:const Padding(
                                    padding: EdgeInsets.all(5),
                                  ),
                                  isExpanded: true,
                                  hint: const Text(
                                    "Assign To",
                                    style: TextStyle(color: Colors.grey),
                                  ),
                                  alignment: Alignment.center,
                                  style: const TextStyle(color: Colors.grey),
                                  items: <String>[
                                    "Assign to",
                                    "Ajay",
                                    "Tarun",
                                    "Shadaab",
                                    "Anubhav",
                                    "Anoop"
                                  ].map((String value){
                                    return DropdownMenuItem<String>(
                                      alignment: Alignment.centerLeft,
                                      child:
                                      Container(
                                        width: 120,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(20),
                                        ),
                                        child: Text(
                                          value,
                                          style: const TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.bold),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                      value: value,
                                    );
                                  }).toList(),
                                  onChanged: (value){
                                    mainController.projectAssign=value!;
                                    mainController.assignTo!.value=value;
                                  },
                                ),
                              ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20,),
                       Row(
                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                         children:  [
                           Text("Add Custom field",style: TextStyle(
                             color: primaryColor,
                             fontSize: 20,
                             fontWeight: FontWeight.bold,
                           ),),
                            Padding(
                             padding: const EdgeInsets.only(right: 20.0),
                             child: InkWell(
                               onTap: (){
                                 if(mainController.c1.length < 3){
                                   mainController.c1.add(TextEditingController());
                                   mainController.q1.add(TextEditingController());
                                 }
                               },
                                 child: const Icon(Icons.add,size: 30,)),
                           ),
                         ],
                       ),
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Obx(()=>
                          ListView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            itemCount: mainController.c1.length,
                              itemBuilder: (BuildContext context,int index){
                            return Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0,top:15,),
                                  child: Container(
                                    decoration:  BoxDecoration(
                                      borderRadius: BorderRadius.circular(10.0),
                                      boxShadow:const[
                                          BoxShadow(
                                            color: Colors.black26,
                                            blurRadius: 1.0,
                                            spreadRadius: 0.0,
                                            offset: Offset(1.0, 1.0), // shadow direction: bottom right
                                          )
                                        ],
                                      color: Colors.white,
                                    ),
                                    height: 45.0,
                                    width: 160,
                                    child:  TextField(
                                      keyboardType: TextInputType.name,
                                      buildCounter: (context,
                                          {required currentLength, required isFocused, maxLength}) {},
                                      onChanged: (value){

                                      },
                                      decoration:  InputDecoration(
                                        enabledBorder: const OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.white,width: 2.0)
                                        ),
                                        fillColor: Colors.white,
                                        filled: true,
                                        hintText: 'C1',
                                        hintStyle: const TextStyle(color: Colors.grey),
                                        focusedBorder:  OutlineInputBorder(
                                            borderSide: BorderSide(color: primaryColor)),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 20),
                                Padding(
                                  padding: const EdgeInsets.only(right: 8.0,top:10,),
                                  child: Container(
                                    decoration:  BoxDecoration(
                                      borderRadius: BorderRadius.circular(10.0),
                                      boxShadow:const[
                                        BoxShadow(
                                          color: Colors.black26,
                                          blurRadius: 1.0,
                                          spreadRadius: 0.0,
                                          offset: Offset(1.0, 1.0), // shadow direction: bottom right
                                        )
                                      ],
                                      color: Colors.white,
                                    ),
                                    height: 45.0,
                                    width: 160,
                                    child:  TextField(
                                      keyboardType: TextInputType.name,
                                      buildCounter: (context,
                                          {required currentLength, required isFocused, maxLength}) {},
                                      onChanged: (value){

                                      },
                                      decoration:  InputDecoration(
                                        enabledBorder: const OutlineInputBorder(
                                            borderSide: BorderSide(color: Colors.white,width: 2.0)
                                        ),
                                        fillColor: Colors.white,
                                        filled: true,
                                        hintText: 'quantity',
                                        hintStyle: const TextStyle(color: Colors.grey),
                                        focusedBorder:  OutlineInputBorder(
                                            borderSide: BorderSide(color: primaryColor)),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            );
                          }),
                        ),
                      ),
                    ],
                  )
              ),
            )
          ],
        ),
      ),
    );
  }
  }
