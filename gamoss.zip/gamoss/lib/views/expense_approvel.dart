import 'package:flutter/material.dart';

class ExpenseApprovalPage extends StatelessWidget {
  const ExpenseApprovalPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(child: const Text("Expense Approval")),
    );
  }
}
