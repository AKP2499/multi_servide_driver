import 'package:flutter/material.dart';
import 'package:gamoss/constant/constant.dart';
import 'package:gamoss/controller/maincontroller.dart';
import 'package:get/get.dart';
import 'drawer_head.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  MainController mainController =Get.put(MainController());
  var currentPage = DrawerSections.attendance;
  var bottomPage = BottomSections.account;

  @override
  Widget build(BuildContext context) {
    if (currentPage == DrawerSections.my_wallet) {
      mainController.pageIndex.value =0;
    } else if (currentPage == DrawerSections.dpr) {
      mainController.pageIndex.value =1;
    } else if (currentPage == DrawerSections.expense_manager) {
      mainController.pageIndex.value =2;
    } else if (currentPage == DrawerSections.store) {
      mainController.pageIndex.value =3;
    } else if (currentPage == DrawerSections.add_funds) {
      mainController.pageIndex.value =4;
    } else if (currentPage == DrawerSections.expense_approval) {
      mainController.pageIndex.value =5;
    }else if(currentPage == DrawerSections.attendance){
      mainController.pageIndex.value=6;
    }else if(bottomPage== BottomSections.account){
      mainController.pageIndex.value=7;
    }
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        backgroundColor: Colors.grey[700],
        title: const Text("Gamoss"),
      ),
      body: mainController.pages[mainController.pageIndex.value],
      bottomNavigationBar: buildMyNavBar(context),
      drawer: Drawer(
        child: SingleChildScrollView(
          child: Container(
            child: Column(
              children: [
                const MyHeaderDrawer(),
                MyDrawerList(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget MyDrawerList() {
    return Container(
      padding: const EdgeInsets.only(
        top: 15,
      ),
      child: Column(
        // shows the list of menu drawer
        children: [
          menuItem(0, "My Wallet", Icons.person_add_alt,
              currentPage == DrawerSections.my_wallet ? true : false),
          menuItem(1, "DPR", Icons.account_box_outlined,
              currentPage == DrawerSections.dpr ? true : false),
          menuItem(2, "Expense Manager", Icons.event,
              currentPage == DrawerSections.expense_manager ? true : false),
          menuItem(3, "Project", Icons.content_paste_sharp,
              currentPage == DrawerSections.store ? true : false),
          menuItem(4, "Add Funds", Icons.money,
              currentPage == DrawerSections.add_funds ? true : false),
          menuItem(5, "Expense Approval", Icons.assignment_outlined,
              currentPage == DrawerSections.expense_approval ? true : false),
          menuItem(6,"Attendance",Icons.account_balance_wallet_outlined,
              currentPage==DrawerSections.attendance?true:false),
        ],
      ),
    );
  }

  Widget menuItem(int id, String title, IconData icon, bool selected) {
    return Material(
      color: selected ? Colors.grey[300] : Colors.transparent,
      child: InkWell(
        onTap: () {
          Navigator.pop(context);
          setState(() {
            if (id == 0) {
              currentPage = DrawerSections.my_wallet;
            } else if (id == 1) {
              currentPage = DrawerSections.dpr;
            } else if (id == 2) {
              currentPage = DrawerSections.expense_manager;
            } else if (id == 3) {
              currentPage = DrawerSections.store;
            } else if (id == 4) {
              currentPage = DrawerSections.add_funds;
            } else if (id == 5) {
              currentPage = DrawerSections.expense_approval;
            } else if(id == 6) {
              currentPage = DrawerSections.attendance;
            }
          });
        },
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Row(
            children: [
              Expanded(
                child: Icon(
                  icon,
                  size: 30,
                  color: primaryColor
                ),
              ),
              const SizedBox(width: 25,),
              Expanded(
                flex: 3,
                child: Text(
                  title,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Container buildMyNavBar(BuildContext context){
    return Container(
    height: 60,
      decoration: const BoxDecoration(boxShadow:  [
        BoxShadow(
          color: Colors.black,
          blurRadius: 2.0,
          spreadRadius: 0.0,
          offset: Offset(2.0, 2.0), // shadow direction: bottom right
        )
      ],
        color:Colors.grey,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child:Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        IconButton(
          enableFeedback: false,
          onPressed: () {
            setState(() {
              mainController.pageIndex.value = 0;
            });
          },
          icon: mainController.pageIndex.value == 0
              ? const Icon(
            Icons.home_filled,
            color: Colors.black,
            size: 35,
          )
              : const Icon(
            Icons.home_outlined,
            color: Colors.black,
            size: 35,
          ),
        ),
        IconButton(
          enableFeedback: false,
          onPressed: () {
            setState(() {
              mainController.pageIndex.value = 1;
            });
          },
          icon: mainController.pageIndex.value == 1
              ? const Icon(
            Icons.work_rounded,
            color: Colors.black,
            size: 35,
          )
              : const Icon(
            Icons.work_outline_outlined,
            color: Colors.black,
            size: 35,
          ),
        ),
        IconButton(
          enableFeedback: false,
          onPressed: () {
            setState(() {
              mainController.pageIndex.value = 2;
            });
          },
          icon: mainController.pageIndex.value == 2
              ? const Icon(
            Icons.widgets_rounded,
            color: Colors.black,
            size: 35,
          )
              : const Icon(
            Icons.widgets_outlined,
            color: Colors.black,
            size: 35,
          ),
        ),
        IconButton(
          enableFeedback: false,
          onPressed: () {
            setState(() {
              mainController.pageIndex.value = 6;
            });
          },
          icon: mainController.pageIndex.value == 6
              ? const Icon(
            Icons.person,
            color: Colors.black,
            size: 35,
          )
              : const Icon(
            Icons.person_outline,
            color: Colors.black,
            size: 35,
          ),
        ),
      ],
    ),
    );
  }

}

enum DrawerSections {
  attendance,
  dpr,
  expense_manager,
  store,
  add_funds,
  expense_approval,
  my_wallet,
  project,
}
enum BottomSections{
  account,
}