import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:gamoss/constant/constant.dart';
import 'package:gamoss/controller/maincontroller.dart';
import 'package:get/get.dart';

class WalletPage extends StatelessWidget {
  const WalletPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    FilePickerResult? result;
    PlatformFile? fileMyWallet;
    Future<void> pickFileMyWallet() async {
      result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ["jbg","png","mp3","pdf"],
      );
      if(result==null)return ;
      fileMyWallet =result!.files.first;

      // openFile(file!);
    }
    MainController mainController =Get.put(MainController());
    return SingleChildScrollView(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Container(
                decoration: BoxDecoration(
                  color: primaryColor,
                  borderRadius: BorderRadius.circular(18.0),
                ),
              height: 130,
              width: 400,
              child:Column(
                      children:  [
                        Row(
                          children:   [
                            const Padding(
                              padding: EdgeInsets.only(left: 20,top: 35.0),
                              child: Icon(Icons.account_balance_wallet_outlined,color: Colors.white,size: 50,),
                            ),
                            Column(
                              children: const [
                                Padding(
                                  padding: EdgeInsets.only(left:30,top: 30),
                                  child: Text("My Wallet",style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 17,
                                  ),),
                                ),
                                SizedBox(height: 5,),
                                Padding(
                                  padding: EdgeInsets.only(right: 20.0),
                                  child: Text("₹ 0.0",style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 19,
                                  ),),
                                ),
                              ],
                            ),
                             Padding(
                              padding: const EdgeInsets.only(left: 110.0,top: 40),
                              child: InkWell(
                                onTap: (){
                                  showDialog(context: context, builder: (context){
                                    return  AlertDialog(
                                      shape: const RoundedRectangleBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(0),
                                        )
                                      ),
                                      backgroundColor: Colors.white,
                                      title: const Text("Request Fund",style: TextStyle(
                                        color: Colors.brown,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                      ),),
                                      content: SizedBox(
                                        height: 200,
                                        width: MediaQuery.of(context).size.width,
                                        child: Column(
                                          children: [
                                            Container(
                                              child: TextField(
                                                cursorColor: Colors.brown,
                                                keyboardType: TextInputType.number,
                                                style:  const TextStyle(
                                                  color: Colors.black,
                                                ),
                                                onChanged: (value){

                                                },
                                                controller: mainController.myControllerWallet,
                                                decoration:   InputDecoration(
                                                  hintText: "Enter Amount",
                                                  labelStyle: const TextStyle(
                                                    color: Colors.brown,
                                                  ),
                                                  enabledBorder: const UnderlineInputBorder(
                                                    borderSide: BorderSide(color: Colors.brown,width: 2.0),
                                                  ),
                                                  focusedBorder: const UnderlineInputBorder(
                                                    borderSide: BorderSide(color:  Colors.black),
                                                  ),
                                                  border: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(height: 20,),
                                            TextField(
                                              cursorColor: Colors.brown,
                                              keyboardType: TextInputType.name,
                                              style:  const TextStyle(
                                                color: Colors.black,

                                              ),
                                              onChanged: (value){

                                              },
                                              controller: mainController.myControllerRemarks,
                                              decoration:  const InputDecoration(
                                                hintText: "Remark",
                                                labelStyle: TextStyle(
                                                  color: Colors.black,
                                                ),
                                                enabledBorder: UnderlineInputBorder(
                                                  borderSide: BorderSide(color: Colors.brown,width: 2),
                                                ),
                                                focusedBorder: UnderlineInputBorder(
                                                  borderSide: BorderSide(color:  Colors.black,width: 1),
                                                ),
                                              ),
                                            ),
                                            InkWell(
                                              onTap: (){
                                                pickFileMyWallet();
                                              },
                                              child: Row(
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets.only(top: 20),
                                                    child:
                                                    (mainController.file=="pdf")?
                                                    Image.asset("assets/pdfimage.png",height: 60,width:60,):
                                                    Image.asset("assets/folder icon_3762805.png",height: 60,width:60,),
                                                  ),
                                                  Column(
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      (fileMyWallet==null)?Container():Container(
                                                        width: 100,
                                                        child: Text(fileMyWallet!.name.toString(),style: const TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 12,
                                                        ),),
                                                      )
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      actions: [
                                        Center(
                                          child: MaterialButton(
                                            onPressed: () {  },
                                            child: const Text("Request"),
                                            color: primaryColor,
                                          ),
                                        )
                                      ],
                                    );
                                  });
                                },
                                  child: const Icon(Icons.add_circle,color: Colors.white,size: 50,)),
                            ),
                          ],
                        ),
                      ],
              ),

            ),
          ),
          const SizedBox(height: 10,),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children:  [
              const Padding(
                padding: EdgeInsets.only(left: 20.0),
                child: Text('Pending',
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),

                ),
              ),
              const SizedBox(height: 10,),
              Container(
                color: Colors.grey.shade400,
                width: MediaQuery.of(context).size.width,
                height: 2,
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 8.0),
            child: ListView.builder(
              shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: 1,
                itemBuilder: (BuildContext context ,int index){
              return  ListTile(
                subtitle: const Text("MM dd,YYYY"),
                leading: Image.asset('assets/wallet.png',
                  height: 30,
                  width: 30,
                ),

                // trailing:  Text(" Debit", style: TextStyle(
                //     color: primaryColor,fontSize: 15),),
                title:  Text("Pending request",style: TextStyle(
                  color: Colors.brown.shade700,
                  fontWeight: FontWeight.bold,
                ),),
              );
            }),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children:  [
               Padding(
                padding: const EdgeInsets.only(left: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    Text('Transactions',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(right: 8.0),
                      child: Text('Type',
                        style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),

                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10,),
              Container(
                color: Colors.grey.shade400,
                width: MediaQuery.of(context).size.width,
                height: 2,
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 8.0),
            child: ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: 4,
                itemBuilder: (BuildContext context ,int index){
                  return  ListTile(
                    subtitle: const Text("MM dd,YYYY"),
                    leading: Image.asset('assets/wallet.png',
                      height: 30,
                      width: 30,
                    ),
                    //Condition Debit and credit if transitions status == Debit show Text(debit) else Text("Credit") and colors

                    trailing:  Text(" Debit", style: TextStyle(
                        color: primaryColor,fontSize: 15),),
                    title:  Text("Amount",style: TextStyle(
                    color: Colors.brown.shade700,
                      fontWeight: FontWeight.bold,
                    ),),
                  );
                }),
          )

        ],
      ),
    );
  }
}


