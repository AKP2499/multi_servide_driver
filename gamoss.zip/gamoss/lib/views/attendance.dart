import 'package:flutter/material.dart';
import 'package:gamoss/constant/constant.dart';

class AttendancePage extends StatelessWidget {
  const AttendancePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        color: Colors.grey.shade200,
        child:  Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 0.0,top: 20),
              child: Text(
                  "My Profile",style: TextStyle(
                color: primaryColor,fontWeight: FontWeight.bold,fontSize: 30,
              ),),
            ),
             const SizedBox(height: 20,),
             Padding(
               padding: const EdgeInsets.only(left: 0.0,),
               child: Center(
                 child: CircleAvatar(
                  backgroundImage: const NetworkImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ42Y1_fnKWKiLCNdi8vu337thvIE4VqCHocQevv6A5jBGt6W3-YMZhz9qcEWEXCofGLNY&usqp=CAU",),
                  radius: 50,
                  backgroundColor: Colors.brown.shade600,
            ),
               ),
             ),
            Container(
              decoration: const BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 1.0,
                      spreadRadius: 0.0,
                      offset: Offset(1.0, 1.0), // shadow direction: bottom right
                    )
                  ]
              ),

              margin: const EdgeInsets.only(left: 20,right: 20,top: 20),
              child: TextFormField(
                // controller: mainController.phone,
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value!.isEmpty && value.length != 10) {
                    return 'Enter invalid number';
                  }
                  return null;
                },
                buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) {},
                maxLength: 10,
                onFieldSubmitted: (value) {
                  print('Second text field : $value');
                },
                onChanged: (value) {
                  // authController.mobile = value;
                  // authController.myControllerPhone.text = value;
                },
                decoration: InputDecoration(
                  enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white,width: 2.0)
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  focusedBorder:  OutlineInputBorder(
                      borderSide: BorderSide(color: primaryColor)),
                  prefixIcon: const Padding(
                    padding: EdgeInsets.all(15),
                    child: Text('+91',style: TextStyle(fontWeight: FontWeight.bold),),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  hintText: 'E.g.9999888777 ',
                  hintStyle: const TextStyle(color: Colors.grey),
                ),
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 1.0,
                      spreadRadius: 0.0,
                      offset: Offset(1.0, 1.0), // shadow direction: bottom right
                    )
                  ]
              ),

              margin: const EdgeInsets.only(left: 20,right: 20,top: 20),
              child: TextField(
                keyboardType: TextInputType.name,
                buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) {},
                onChanged: (value){},
                decoration:  InputDecoration(
                  enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white,width: 2.0)
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: 'Email ',
                  hintStyle: const TextStyle(color: Colors.grey),
                  focusedBorder:  OutlineInputBorder(
                      borderSide: BorderSide(color: primaryColor)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 1.0,
                      spreadRadius: 0.0,
                      offset: Offset(1.0, 1.0), // shadow direction: bottom right
                    )
                  ]
              ),
              margin: const EdgeInsets.only(left: 20,right: 20,top: 20),
              child: TextField(
                keyboardType: TextInputType.name,
                buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) {},
                onChanged: (value){},
                decoration:  InputDecoration(
                  enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white,width: 2.0)
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: 'Name',
                  hintStyle: const TextStyle(color: Colors.grey),
                  focusedBorder:  OutlineInputBorder(
                      borderSide: BorderSide(color: primaryColor)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                  boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 1.0,
                    spreadRadius: 0.0,
                    offset: Offset(1.0, 1.0), // shadow direction: bottom right
                  )
                  ]
              ),
              margin: const EdgeInsets.only(left: 20,right: 20,top: 20,bottom: 10),
              child: TextField(
                keyboardType: TextInputType.name,

                buildCounter: (context,
                    {required currentLength, required isFocused, maxLength}) {},
                onChanged: (value){},
                decoration:  InputDecoration(
                  enabledBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white,width: 2.0)
                  ),
                  fillColor: Colors.white,
                  filled: true,
                  hintText: 'User Type',
                  hintStyle: const TextStyle(color: Colors.grey),
                  focusedBorder:  OutlineInputBorder(
                      borderSide: BorderSide(color: primaryColor)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(30, 10, 30, 10),
              padding: const EdgeInsets.fromLTRB(10,2,10,2),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: primaryColor,
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextButton(onPressed: () {  },
              child: const Text("Update Profile", style: TextStyle(color: Colors.white, fontSize: 16),),


              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(30, 10, 30, 10),
              padding: const EdgeInsets.fromLTRB(10,2,10,2),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextButton(onPressed: () {  },
                child:  Text("Logout", style: TextStyle(color: primaryColor, fontSize: 16),),


              ),
            )
          ],
        ),
      ),
    );
  }
}
