import 'package:flutter/material.dart';
import 'package:gamoss/views/login_page.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
void main() {
  runApp(
    const NewApp()
  );
}

class NewApp extends StatelessWidget {
  const NewApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      color: Colors.grey.shade200,
      debugShowCheckedModeBanner: false,

      // theme: ThemeData(
      //   primaryColor: Colors.grey.shade200,
      // ),
      home: const Signin(),
    );
  }
}
